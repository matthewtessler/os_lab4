Student Name: Matthew Tessler
NET ID: mt2837
Project Language: Java
Running Instructions: 
	
	javac paging.java <-- compile
	java paging INPUT GOES HERE <-- execute

Example Running (input 1):  
	
	javac paging.java
	java paging 10 10 20 1 10 lru 0 

Notes: 

	I have included the debugging output functionality although it is not required. 
	If debugging output is equal to 0, the normal output is printed. (10 10 20 1 10 lru 0)
	If debugging output is equal to 1, the debugging output is printed. (10 10 20 1 10 lru 1)
	If debugging output is equal to 11, the debugging and random output is printed. (10 10 20 1 10 lru 11) 

	So a normal run for normal credit would just be with 0, as the standard inputs are.

All outputs are correct according to my testing.

The functions that print the frame table, process tables, and the frame table and process table together
are functional but not perfectly aligned for all outputs. They are usable but not visually perfect. 




